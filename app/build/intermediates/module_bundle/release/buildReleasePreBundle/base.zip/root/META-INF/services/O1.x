P1.b
